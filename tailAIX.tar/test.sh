./tail -F tploader.log | /home/xd/src/tploaderParser/parser 0 dummy ./send_nsca 192.168.0.30 ./send_nsca.conf 0 /home/xd/src/perl/debugOut1 0
